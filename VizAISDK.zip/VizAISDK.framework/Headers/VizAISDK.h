//
//  VizAISDK.h
//  VizAISDK
//
//  Created by Ethan Petersen on 12/20/17.
//  Copyright © 2017 Ethan Petersen. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VizAISDK.
FOUNDATION_EXPORT double VizAISDKVersionNumber;

//! Project version string for VizAISDK.
FOUNDATION_EXPORT const unsigned char VizAISDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VizAISDK/PublicHeader.h>


